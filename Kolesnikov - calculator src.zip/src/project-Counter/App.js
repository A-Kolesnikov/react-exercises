//import logo from '../logo.svg';
import '../App.css';
import React from 'react';
import { Counter } from './Counter';
import { Component } from "react";

class App extends Component {
  render(){
    return(
      <div>
        <Counter />
        
      </div>
    )
  }
}

export default App;
