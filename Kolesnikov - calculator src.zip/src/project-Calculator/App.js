//import logo from '../logo.svg';
import '../App.css';
import React from 'react';
import { Calc } from './Calc';
import { Component } from "react";

class App extends Component {
  render(){
    return(
      <div>
        <Calc />
        
      </div>
    )
  }
}

export default App;